   


    $(document).ready(function () {

$("#bt1").click(function() {
       
		var value = 50,value2=50,value3=100,value4=100,value5=100;

		    animateProgressBar(value);
        animateProgressBar2(value2);
        animateProgressBar3(value3);
        animateProgressBar4(value4);
        animateProgressBar5(value5);
        


<!--button1-->
        setInterval(function () {
     	
     	value-=5;
     	animateProgressBar(value);

     	if (value<30) {$('#bak').attr("src","cry.gif")}
     			if(value==25){alert("বাইরে থেকে আসার পর পরিষ্কার হবার আগে বাচ্চাকে জড়িয়ে ধরবেন না।");}
          else if(value<50){
            if(value==45){alert("বাচ্চাচ্চাকে ধরার আগে অবশ্যই হাত পরিস্কার করুন।");}

            $('#bak').attr("src","InnoFace.gif")

            
          };
          

     }, 10000);
        

<!--button2-->


         setInterval(function () {
        
        value2-=5;
        animateProgressBar2(value2);

        if (value2<30) {$('#bak').attr("src","cry.gif")}
          if(value2==25){alert("বিশেষ পরামর্শ দেওয়া হচ্ছে যে শিশু প্রথম ৬ মাসের প্রায় একচেটিয়াভাবে মাতৃদুগ্ধ দিন,, ডায়রিয়া এবং শ্বাসযন্ত্রের সংক্রমণ সহ বিভিন্ন ধরণের সংক্রামক রোগ থেকে শিশুকে রক্ষা করে");}
                else if(value2<50){$('#bak').attr("src","InnoFace.gif")};
                if(value2==45){alert("বাাচ্চার জন্মের আধা থেকে ২ ঘণ্টার মধ্যে বুকের দুধ খাওয়ান এবং বুকের দুধ ছাড়া আর কিছু খাওয়াবেন না");}

     }, 10000);

<!--button3-->


         setInterval(function () {
        
        value3-=5;
        animateProgressBar3(value3);

        if (value2<30) {$('#bak').attr("src","cry.gif")}
                else if(value2<50){$('#bak').attr("src","InnoFace.gif")};


     }, 30000);


<!--button4-->


         setInterval(function () {
        
        value4-=5;
        animateProgressBar4(value2);

        if (value2<30) {$('#bak').attr("src","cry.gif")}
                else if(value2<50){$('#bak').attr("src","InnoFace.gif")};


     }, 30000);


<!--button5-->


         setInterval(function () {
        
        value5-=5;
        animateProgressBar5(value2);

        if (value2<30) {$('#bak').attr("src","cry.gif")}
                else if(value2<50){$('#bak').attr("src","InnoFace.gif")};


     }, 30000);





          	
<!-- animate fun -->
	<!--button1-->

            function animateProgressBar(percentageCompleted) {
                $('#innerDiv').animate({
                    'width': (70 * percentageCompleted) / 100
                }, 3000);

                $({ counter: 1 }).animate({ counter: percentageCompleted }, {
                    duration: 3000,
                    step: function () {
                        $('#innerDiv').text(Math.ceil(this.counter) + ' %');
                    }
                })
            }


    <!--button2-->
            function animateProgressBar2(percentageCompleted) {
                $('#innerDiv2').animate({
                    'width': (70 * percentageCompleted) / 100
                }, 3000);

                $({ counter: 1 }).animate({ counter: percentageCompleted }, {
                    duration: 3000,
                    step: function () {
                        $('#innerDiv2').text(Math.ceil(this.counter) + ' %');
                    }
                })
            }


<!--button3-->
            function animateProgressBar3(percentageCompleted) {
                $('#innerDiv3').animate({
                    'width': (70 * percentageCompleted) / 100
                }, 3000);

                $({ counter: 1 }).animate({ counter: percentageCompleted }, {
                    duration: 3000,
                    step: function () {
                        $('#innerDiv3').text(Math.ceil(this.counter) + ' %');
                    }
                })
            }


<!--button4-->
            function animateProgressBar4(percentageCompleted) {
                $('#innerDiv4').animate({
                    'width': (70 * percentageCompleted) / 100
                }, 3000);

                $({ counter: 1 }).animate({ counter: percentageCompleted }, {
                    duration: 3000,
                    step: function () {
                        $('#innerDiv4').text(Math.ceil(this.counter) + ' %');
                    }
                })
            }

<!--button5-->
            function animateProgressBar5(percentageCompleted) {
                $('#innerDiv5').animate({
                    'width': (70 * percentageCompleted) / 100
                }, 3000);

                $({ counter: 1 }).animate({ counter: percentageCompleted }, {
                    duration: 3000,
                    step: function () {
                        $('#innerDiv5').text(Math.ceil(this.counter) + ' %');
                    }
                })
            }



<!---button dress 1--->

            $("#d1").click(function() {
              value=100;
            $('#bak').attr("src","HappFace.gif")   
            $('#bak2').attr("src","HappFace.gif") 
            $('#bak3').attr("src","HappFace.gif")   
            $('#bak4').attr("src","HappFace.gif") 
            });
 


 <!---button dress 2--->     


            $("#d2").click(function() {
              value=100;
            $('#bak').attr("src","d1.gif")   
            $('#bak2').attr("src","d1.gif") 
            $('#bak3').attr("src","d1.gif")   
            $('#bak4').attr("src","d1.gif") 
            });
 

<!---button dress 3--->
        

   $("#d3").click(function() {
            value=100;
            $('#bak').attr("src","d2.gif")   
            $('#bak2').attr("src","d2.gif") 
            $('#bak3').attr("src","d2.gif")   
            $('#bak4').attr("src","d2.gif") 
            });
 


        
<!---button dress 4--->
$("#d4").click(function() {
            value=100;
            $('#bak').attr("src","d3.gif")   
            $('#bak2').attr("src","d3.gif") 
            $('#bak3').attr("src","d3.gif")   
            $('#bak4').attr("src","d3.gif") 
            });
 
            
$("#food2").click(function() {
        alert("বতল দুধ ৬ মাস পর্যন্ত দেবন না ");    
            });
 
 $("#food1").click(function() {
           value2=100;

           alert("আপনার শিশু খাবার খেএছে ");  
            });








});





        });






   <!--slider-->


  